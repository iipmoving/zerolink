Example Description 

  This example describes how to implement a cycle-by-cycle (CBC) current control 
  with complementary signals and dead time insertion.
  An overcurrent condition will turn-off the two complementary outputs, without 
  re-arming the complementary output.

  Two complementary PWM waveforms are generated on the TD1 and TD2 outputs 
  (resp. PC11 and PC12).
  The over-current digital signal must be connected to both EEV5 and EEV8 external event 
  lines on PB8 and PB9 inputs.

  LED2 : blinks during normal operation
  LED2 : ON when the ERROR handler is entered

GPIO

  LED2 : PA5