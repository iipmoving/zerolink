/**
 * @file circular_queue.h
 * @brief 循环队列封装 - A进程写入，B进程读取
 */

#ifndef __CIRCULAR_QUEUE_H__
#define __CIRCULAR_QUEUE_H__

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>
#include <stdbool.h>

// 队列最大容量定义（可根据需要修改）
#define QUEUE_MAX_SIZE    5

/**
 * @brief 队列结构体
 */
typedef struct {
    uint8_t buffer[QUEUE_MAX_SIZE];  // 队列缓冲区
    uint16_t front;                  // 读指针（B进程使用）
    uint16_t rear;                   // 写指针（A进程使用）
    uint16_t count;                  // 当前数据个数
    bool is_full;                    // 队列满标志
} CircularQueue;

/**
 * @brief 初始化队列
 * @param queue 队列指针
 */
void queue_init(CircularQueue *queue);

/**
 * @brief A进程：向队列写入数据
 * @param queue 队列指针
 * @param data 要写入的数据
 * @return true:写入成功 false:队列已满
 */
bool queue_write(CircularQueue *queue, uint8_t data);

/**
 * @brief A进程：批量写入数据
 * @param queue 队列指针
 * @param data 数据数组
 * @param length 数据长度
 * @return 实际写入的数据个数
 */
uint16_t queue_write_batch(CircularQueue *queue, uint8_t *data, uint16_t length);

/**
 * @brief B进程：从队列读取数据 单字节返回
 * @param queue 队列指针
 * @return >0:读取数据 0:队列为空
 */
uint8_t  queue_read_one(CircularQueue *queue);

/**
 * @brief B进程：从队列读取数据
 * @param queue 队列指针
 * @param data 读取的数据存放地址
 * @return true:读取成功 false:队列为空
 */
bool  queue_read(CircularQueue *queue,uint8_t *data);


/**
 * @brief B进程：批量读取数据
 * @param queue 队列指针
 * @param buffer 数据缓冲区
 * @param max_length 最大读取长度
 * @return 实际读取的数据个数
 */
uint16_t queue_read_batch(CircularQueue *queue, uint8_t *buffer, uint16_t max_length);

/**
 * @brief B进程：读取数据但不移动指针（预读）
 * @param queue 队列指针
 * @param data 读取的数据存放地址
 * @return true:读取成功 false:队列为空
 */
bool queue_peek(CircularQueue *queue, uint8_t *data);

/**
 * @brief B进程：重置队列（读完后调用）
 * @param queue 队列指针
 */
void queue_reset(CircularQueue *queue);

/**
 * @brief 获取队列当前数据个数
 * @param queue 队列指针
 * @return 数据个数
 */
uint16_t queue_get_count(CircularQueue *queue);

/**
 * @brief 检查队列是否为空
 * @param queue 队列指针
 * @return true:队列空 false:队列非空
 */
bool queue_is_empty(CircularQueue *queue);

/**
 * @brief 检查队列是否已满
 * @param queue 队列指针
 * @return true:队列满 false:队列未满
 */
bool queue_is_full(CircularQueue *queue);

/**
 * @brief 获取队列剩余空间
 * @param queue 队列指针
 * @return 剩余空间大小
 */
uint16_t queue_get_free_space(CircularQueue *queue);

#ifdef __cplusplus
}
#endif

#endif /* __CIRCULAR_QUEUE_H__ */