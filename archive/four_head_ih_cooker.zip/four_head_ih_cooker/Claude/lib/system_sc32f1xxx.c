/**
 * system_sc32f1xxx.c —— 系统时钟初始化
 *
 * 默认使用 HIRC 48MHz 作为系统时钟
 * HCLK = SYSCLK / 1 = 48MHz
 * APB0 = APB1 = APB2 = HCLK / 1 = 48MHz
 */
#include "sc32f1xxx_rcc.h"
#include "system_sc32f1xxx.h"

uint32_t SystemCoreClock = 48000000u;

void SystemInit(void)
{
    /* 使能HIRC（内部48MHz，上电默认已使能） */
    RCC_HIRCCmd(ENABLE);

    /* 选择HIRC(48MHz)作为系统时钟（默认HIRC/2=24MHz，切换到全速） */
    RCC_SYSCLKConfig(RCC_SYSCLKSource_HIRC);

    /* HCLK不分频 */
    RCC_HCLKConfig(RCC_SYSCLK_Div1);

    /* APB0/1/2 不分频 */
    RCC_APB0Config(RCC_HCLK_Div1);
    RCC_APB1Config(RCC_HCLK_Div1);
    RCC_APB2Config(RCC_HCLK_Div1);

    SystemCoreClockUpdate();
}

void SystemCoreClockUpdate(void)
{
    /* 当前默认 HIRC 48MHz, HCLK/APB 均不分频 */
    SystemCoreClock = 48000000u;
}
