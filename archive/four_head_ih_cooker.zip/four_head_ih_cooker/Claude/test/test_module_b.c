/**
 * test_module_b.c —— 测试模块B（How are you 对话应答方）
 *
 * 依赖: msg_scheduler.h + hal_uart.h
 * 特点: 不include test_module_a.h，纯消息通信
 *
 * 对话流:
 *   B ←MSG_TEST_CHAT_A(round)— A
 *   B —MSG_TEST_CHAT_B(round)→ A   (立即Post，1ms后A收到)
 */
#include "core/msg_scheduler.h"
#include "hal/hal_uart.h"

/* 收到A的问候 */
static void B_OnChatA(MsgId_t id, uint16_t param, void *data_ptr)
{
    (void)id;
    (void)data_ptr;

    HAL_UART_Debug_Print("  [B] recv <- A: \"How are you?\" (round=");
    HAL_UART_Debug_PutChar('0' + (uint8_t)param);
    HAL_UART_Debug_Print(")\r\n");

    /* 回复: 此消息将在1ms后被A消费 */
    HAL_UART_Debug_Print("  [B] send -> A: \"I'm fine, thank you!\" (round=");
    HAL_UART_Debug_PutChar('0' + (uint8_t)param);
    HAL_UART_Debug_Print(")\r\n");
    Msg_Post(MSG_TEST_CHAT_B, param, NULL);
}

/* 初始化: 注册对A消息的监听 */
void TestB_Init(void)
{
    MsgScheduler_Register(MSG_TEST_CHAT_A, B_OnChatA);
}
