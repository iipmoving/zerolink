/**
 * test_module_a.c —— 测试模块A（How are you 对话发起方）
 *
 * 依赖: msg_scheduler.h + hal_uart.h
 * 特点: 不include test_module_b.h，纯消息通信
 *
 * 对话流:
 *   A —MSG_TEST_CHAT_A(round=0)→ B
 *   A ←MSG_TEST_CHAT_B(round=0)— B   (1ms后)
 *   A —MSG_TEST_CHAT_A(round=1)→ B   (1ms后)
 *   ...共5轮
 */
#include "core/msg_scheduler.h"
#include "hal/hal_uart.h"

#define CHAT_ROUNDS 5u

static uint8_t s_round;

/* 收到B的回复 */
static void A_OnChatB(MsgId_t id, uint16_t param, void *data_ptr)
{
    (void)id;
    (void)data_ptr;

    HAL_UART_Debug_Print("  [A] recv <- B: \"I'm fine, thank you!\" (round=");
    HAL_UART_Debug_PutChar('0' + (uint8_t)param);
    HAL_UART_Debug_Print(")\r\n");

    s_round = (uint8_t)param + 1u;
    if (s_round < CHAT_ROUNDS) {
        /* 下一轮: 此消息将在1ms后被B消费 */
        HAL_UART_Debug_Print("  [A] send -> B: \"How are you?\" (round=");
        HAL_UART_Debug_PutChar('0' + s_round);
        HAL_UART_Debug_Print(")\r\n");
        Msg_Post(MSG_TEST_CHAT_A, s_round, NULL);
    } else {
        HAL_UART_Debug_Print("  [A] chat end.\r\n");
    }
}

/* 由main.c在注册后调用一次，发起对话 */
void TestA_StartChat(void)
{
    s_round = 0u;
    HAL_UART_Debug_Print("\r\n=== Chat Demo Start (2 modules, 1ms/msg) ===\r\n");
    HAL_UART_Debug_Print("  [A] send -> B: \"How are you?\" (round=0)\r\n");
    Msg_Post(MSG_TEST_CHAT_A, 0u, NULL);
}

/* 初始化: 注册对B消息的监听 */
void TestA_Init(void)
{
    MsgScheduler_Register(MSG_TEST_CHAT_B, A_OnChatB);
}
