/**
 * main.c —— 四头电磁炉控制程序入口
 *
 * 调度模式:
 *   每1ms: 起始段(MsgScheduler) + 执行段(轮转1个槽)
 *   10槽 × 1ms = 10ms 完整周期
 *   每个模块每10ms被调用一次，用调用次数做独立计时
 *
 * 不依赖 hal_timer 计时 —— 模块自己数调用次数
 */
#include "sc32_conf.h"
#include "system_sc32f1xxx.h"
#include "hal/hal_timer.h"
#include "hal/hal_uart.h"
#include "hal/hal_gpio.h"
#include "core/msg_scheduler.h"
#include "test/test_module_a.h"
#include "test/test_module_b.h"
#include "drv/drv_key.h"

/* ========== 按键事件处理 ========== */
static void Key_OnEvent(MsgId_t id, uint16_t param, void *data_ptr)
{
    uint8_t key_code = (uint8_t)(param & 0xFFu);
    uint8_t key_state = (uint8_t)((param >> 8) & 0xFFu);
    (void)id; (void)data_ptr;

    if (key_state == KEY_STATE_PRESS) {
        HAL_UART_Debug_Print("[KEY] Press  code=0x");
        HAL_UART_Debug_HexDump(&key_code, 1u);
        HAL_UART_Debug_Print("\r\n");
    } else if (key_state == KEY_STATE_RELEASE) {
        HAL_UART_Debug_Print("[KEY] Release code=0x");
        HAL_UART_Debug_HexDump(&key_code, 1u);
        HAL_UART_Debug_Print("\r\n");
    }
}

/* ========== 心跳指示 ========== */
static void Heartbeat_OnTimer100ms(MsgId_t id, uint16_t param, void *data_ptr)
{
    (void)id; (void)param; (void)data_ptr;
    HAL_GPIO_Toggle(HAL_IO_BUZZER);
}

/* ========== 槽位0: 定时消息生成 ========== */
/* 本槽每10ms调用一次，数10次=100ms，数100次=1s */
static void Slot_TimerTick(void)
{
    static uint8_t  cnt_100ms;   /* 调用次数 0..9 → 100ms */
    static uint16_t cnt_1s;      /* 调用次数 0..99 → 1s */

    cnt_100ms++;
    if (cnt_100ms >= 10u) {
        cnt_100ms = 0u;
        Msg_Post(MSG_TIMER_100MS, 0u, NULL);
    }

    cnt_1s++;
    if (cnt_1s >= 100u) {
        cnt_1s = 0u;
        Msg_Post(MSG_TIMER_1S, 0u, NULL);
    }
}

/* ========== 10槽分配 ========== */
/*
 * 每槽1ms，10槽=10ms完整周期:
 *   0: 定时消息(100ms/1s)
 *   1: 显示控制
 *   2: 功率/输出控制
 *   3: 按键处理
 *   4: 通讯处理
 *   5: 保护/故障检测
 *   6-9: 预留
 */
static uint8_t s_prog_slot;

static void ExecSlot_Run(void)
{
    switch (s_prog_slot) {
    case 0u: Slot_TimerTick();     break;
    case 1u: /* 显示控制 */        break;
    case 2u: /* 功率/输出控制 */   break;
    case 3u: Drv_Key_Scan();        break;
    case 4u: /* 通讯处理 */        break;
    case 5u: /* 保护/故障检测 */   break;
    case 6u:
    case 7u:
    case 8u:
    case 9u: /* 预留 */            break;
    default: break;
    }
}

/* ========== 主函数 ========== */
int main(void)
{
    HAL_UART_Debug_Init();
    HAL_UART_Debug_Print("\r\n=== Four-Head IH Cooker Boot ===\r\n");

    HAL_GPIO_Init();
    MsgScheduler_Init();

    MsgScheduler_Register(MSG_TIMER_100MS, Heartbeat_OnTimer100ms);
    MsgScheduler_Register(MSG_KEY_EVENT, Key_OnEvent);
    TestA_Init();
    TestB_Init();
    Drv_Key_Init();

    s_prog_slot = 0u;
    HAL_Timer_Init();

    HAL_UART_Debug_Print("[SYS] Init done, starting chat demo.\r\n");
    TestA_StartChat();

    for (;;) {
        if (HAL_Timer_1msElapsed()) {
            /* === 起始段: 每1ms消费一条消息 === */
            MsgScheduler_Run1ms();

            /* === 执行段: 轮转一个槽（每1ms一个） === */
            ExecSlot_Run();
            s_prog_slot = (s_prog_slot + 1u) % 10u;
        }

        /* === 等待段: 剩余CPU时间做轮询 === */
        /* Comm_Service();  -- 通讯解码等 */
    }
}
