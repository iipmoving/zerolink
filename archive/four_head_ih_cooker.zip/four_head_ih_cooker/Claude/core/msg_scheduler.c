/**
 * msg_scheduler.c —— 消息调度器实现
 *
 * 依赖: msg_scheduler.h + msg_def.h
 *
 * 环形队列：Msg_Post 写入 → MsgScheduler_Run1ms 取出消费
 * 回调注册表：同一消息ID可注册多个回调，分发时依次调用
 */
#include "msg_scheduler.h"

/* ========== 消息槽（环形队列） ========== */
static Msg_t     s_msg_slot[MSG_SLOT_DEPTH];
static uint8_t   s_slot_head;       /* 消费指针（Run1ms 取走）            */
static uint8_t   s_slot_tail;       /* 生产指针（Msg_Post 写入）          */
static uint8_t   s_slot_count;      /* 当前槽中消息数                     */

/* ========== 回调注册表 ========== */
typedef struct {
    MsgId_t       msg_id;
    MsgHandler_t  handler;
} HandlerEntry_t;

static HandlerEntry_t s_handlers[MAX_HANDLERS];
static uint8_t        s_handler_count;

/* ========== 初始化 ========== */
void MsgScheduler_Init(void)
{
    s_slot_head  = 0u;
    s_slot_tail  = 0u;
    s_slot_count = 0u;
    s_handler_count = 0u;
}

/* ========== 注册 ========== */
void MsgScheduler_Register(MsgId_t id, MsgHandler_t handler)
{
    if (handler == NULL) return;
    if (s_handler_count >= MAX_HANDLERS) return;

    s_handlers[s_handler_count].msg_id  = id;
    s_handlers[s_handler_count].handler = handler;
    s_handler_count++;
}

/* ========== 发送消息 ========== */
void Msg_Post(MsgId_t id, uint16_t param, void *data_ptr)
{
    if (s_slot_count >= MSG_SLOT_DEPTH) return;  /* 槽满，丢弃（实际不会发生） */

    s_msg_slot[s_slot_tail].id       = id;
    s_msg_slot[s_slot_tail].param    = param;
    s_msg_slot[s_slot_tail].data_ptr = data_ptr;

    s_slot_tail = (s_slot_tail + 1u) % MSG_SLOT_DEPTH;
    s_slot_count++;
}

/* ========== 1ms调度入口 ========== */
void MsgScheduler_Run1ms(void)
{
    uint8_t i;

    if (s_slot_count == 0u) return;  /* 无消息，直接返回                    */

    /* 取出一条消息 */
    Msg_t msg = s_msg_slot[s_slot_head];
    s_slot_head = (s_slot_head + 1u) % MSG_SLOT_DEPTH;
    s_slot_count--;

    /* 遍历注册表，匹配的消息ID全部回调 */
    for (i = 0u; i < s_handler_count; i++) {
        if (s_handlers[i].msg_id == msg.id) {
            s_handlers[i].handler(msg.id, msg.param, msg.data_ptr);
        }
    }
}

/* ========== 编译期验证 ========== */
CT_ASSERT(sizeof(Msg_t) <= 16,   msg_size_chk);
CT_ASSERT(MSG_SLOT_DEPTH <= 8u,  slot_depth);
CT_ASSERT(MAX_HANDLERS <= 16u,   handler_cnt);
