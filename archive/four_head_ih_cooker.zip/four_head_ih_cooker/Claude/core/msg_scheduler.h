/**
 * msg_scheduler.h —— 消息调度器接口
 *
 * 依赖: msg_def.h（唯一）
 * 调度器只操作 Msg_t，永不解包 data_ptr 内容
 */
#ifndef MSG_SCHEDULER_H
#define MSG_SCHEDULER_H

#include "msg_def.h"

/* ========== 配置常量 ========== */
#define MSG_SLOT_DEPTH   8u    /* 环形队列深度                           */
#define MAX_HANDLERS     16u   /* 最大回调注册数                          */

/* ========== 公共接口 ========== */

/* 初始化调度器 */
void MsgScheduler_Init(void);

/* 注册回调：同一消息ID可注册多个回调，依次调用 */
void MsgScheduler_Register(MsgId_t id, MsgHandler_t handler);

/* 发送消息（任意模块调用） */
void Msg_Post(MsgId_t id, uint16_t param, void *data_ptr);

/* 1ms调度入口（定时中断中调用）—— 消费一条消息 */
void MsgScheduler_Run1ms(void);

#endif /* MSG_SCHEDULER_H */
