/**
 * msg_def.h —— 消息核心定义（零依赖）
 *
 * 本文件只定义:
 *   - MsgId_t  消息ID枚举
 *   - Msg_t    通用消息结构(id + param + void* data_ptr)
 *   - MsgHandler_t 回调函数类型
 *
 * ★ 不定义任何业务结构体 —— 各模块在自己 .h 中定义
 * ★ 调度器只传递 void*，永不 dereference
 */
#ifndef MSG_DEF_H
#define MSG_DEF_H

#include <stdint.h>
#include <stddef.h>

/* 可移植编译期断言（C89+ARMCC V5 兼容） */
#define CT_ASSERT(expr, tag) extern int __ct_##tag[(expr) ? 1 : -1]

/* ========== 消息ID ========== */
typedef enum {
    MSG_KEY_EVENT,            /* 按键事件      param=键值                         */
    MSG_COOKING_CTRL,         /* 烹饪控制命令  param:高8=炉头号,低8=命令           */
    MSG_POWER_CTRL,           /* 功率下发      data_ptr→PowerCtrl_t               */
    MSG_FAN_CTRL,             /* 风机控制      param=档位0-3                      */
    MSG_DISPLAY_REFRESH,      /* 显示刷新      param=DisplayCmd_t编码              */
    MSG_TIMER_100MS,          /* 100ms节拍    param=无                           */
    MSG_TIMER_1S,             /* 1秒节拍      param=无                           */
    MSG_COMM_TX_DONE,         /* MODBUS收发完成 param=炉头号                       */
    MSG_COMM_DATA_UPDATE,     /* 通讯数据更新  data_ptr→ModbusData_t               */
    MSG_SYSTEM_ERROR,         /* 系统错误      data_ptr→ProtectFault_t             */
    MSG_TEST_CHAT_A,          /* 测试对话A     param=轮次                          */
    MSG_TEST_CHAT_B,          /* 测试对话B     param=轮次                          */
    MSG_COUNT                 /* 消息总数（数组大小用）                             */
} MsgId_t;

/* ========== 通用消息结构 ========== */
#pragma pack(4)
typedef struct {
    MsgId_t  id;              /* 消息ID                                          */
    uint16_t param;           /* 轻量数值（键码/档位…），复杂数据走 data_ptr       */
    void    *data_ptr;        /* 指向模块自定义结构体，调度器永不解包              */
} Msg_t;
#pragma pack()

CT_ASSERT(sizeof(Msg_t) <= 16, msg_size);

/* ========== 回调函数类型 ========== */
typedef void (*MsgHandler_t)(MsgId_t id, uint16_t param, void *data_ptr);

#endif /* MSG_DEF_H */
