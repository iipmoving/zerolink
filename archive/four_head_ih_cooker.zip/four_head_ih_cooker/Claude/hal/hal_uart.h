/**
 * hal_uart.h —— UART调试打印接口
 *
 * 依赖: sc32f1xxx_uart.h（固件库）
 * 层级: HAL —— 只封装硬件操作，不include msg_def.h
 *
 * UART1 用作调试输出（阻塞式TX，仅调试用，不影响消息系统）
 * UART0 保留给 MODBUS 通讯（后续 proto_modbus 使用）
 */
#ifndef HAL_UART_H
#define HAL_UART_H

#include <stdint.h>

/* 初始化调试UART（UART1, 115200-8-N-1） */
void HAL_UART_Debug_Init(void);

/* 发送单个字节（阻塞） */
void HAL_UART_Debug_PutChar(uint8_t ch);

/* 发送字符串 */
void HAL_UART_Debug_Print(const char *str);

/* 发送hex dump */
void HAL_UART_Debug_HexDump(const uint8_t *data, uint16_t len);

#endif /* HAL_UART_H */
