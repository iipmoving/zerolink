/**
 * hal_key.h —— 触摸按键HAL接口
 *
 * 依赖: 无（仅 stdint.h）
 * 层级: HAL —— 封装赛元触摸库
 *
 * 触摸库使用: TK_Init → TK_TouchKeyScan(轮询) → TK_Restart
 * 21键触摸面板: 通道7-24, 28-30
 */
#ifndef HAL_KEY_H
#define HAL_KEY_H

#include <stdint.h>

void HAL_Key_Init(void);

/* 扫描触摸按键，返回原始位掩码。
 * 调用者通过 Bit_SYS_Read_Key 判断是否有新数据。
 * 返回 0 = 无按键或无新数据 */
uint32_t HAL_Key_Scan(void);

#endif /* HAL_KEY_H */
