/**
 * hal_timer.c —— TIM0 1ms时基实现
 *
 * 依赖: hal_timer.h + 固件库
 * 层级: HAL —— 不include msg_scheduler.h
 *
 * ISR: 只设1ms标志，不做任何业务处理
 * TIM0: APB0=48MHz, Prescaler=64→750kHz, Preload=749→1ms
 */
#include "hal_timer.h"
#include "sc32f1xxx_tim.h"
#include "sc32f1xxx_rcc.h"
#include "sc32L14xx.h"

static volatile uint32_t s_tick_ms;
static volatile uint8_t  s_1ms_pending;

#define TIM0_PRESCALER   TIM_PRESCALER_64
#define TIM0_PRELOAD     749u

void HAL_Timer_Init(void)
{
    TIM_TimeBaseInitTypeDef tim_init;

    s_tick_ms     = 0u;
    s_1ms_pending = 0u;

    RCC_APB0PeriphClockCmd(RCC_APB0Periph_TIM0, ENABLE);

    TIM_TimeBaseStructInit(&tim_init);
    tim_init.TIM_Prescaler   = TIM0_PRESCALER;
    tim_init.TIM_WorkMode    = TIM_WorkMode_Timer;
    tim_init.TIM_CounterMode = TIM_CounterMode_Up;
    tim_init.TIM_EXENX       = TIM_EXENX_Disable;
    tim_init.TIM_Preload     = TIM0_PRELOAD;
    TIM_TIMBaseInit(TIM0, &tim_init);

    TIM_ITConfig(TIM0, TIM_IT_TI, ENABLE);

    NVIC_SetPriority(TIMER0_IRQn, 1u);
    NVIC_EnableIRQ(TIMER0_IRQn);

    TIM_Cmd(TIM0, ENABLE);
}

uint32_t HAL_Timer_GetTick(void)
{
    return s_tick_ms;
}

uint8_t HAL_Timer_1msElapsed(void)
{
    if (s_1ms_pending != 0u) {
        s_1ms_pending = 0u;
        return 1u;
    }
    return 0u;
}

/* ========== TIM0中断 —— 只设标志 ========== */
void TIMER0_IRQHandler(void)
{
    TIM_ClearFlag(TIM0, TIM_Flag_TI);
    s_tick_ms++;
    s_1ms_pending = 1u;
}
