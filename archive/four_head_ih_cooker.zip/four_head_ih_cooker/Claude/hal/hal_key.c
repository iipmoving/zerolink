/**
 * hal_key.c —— 触摸按键HAL实现
 *
 * 依赖: TKDriver.h + SC_TK_Scan.h
 * 层级: HAL —— 不include任何业务模块头文件
 *
 * 触摸库使用说明:
 *   1. TK_Init() 初始化触摸模块
 *   2. TK_TouchKeyStatus & 0x80 → 一轮扫描完成
 *   3. 清除标志 TK_TouchKeyStatus &= 0x7f
 *   4. TK_TouchKeyScan() 获取按键位掩码(64bit)
 *   5. TK_Restart() 启动下一轮扫描
 */
#include "hal_key.h"
#include "../lib/SC_TK_Scan.h"
#include "../lib/MCU_Drivers/TKDriverNew/TKDriver.h"

/* TK_TouchKeyStatus 由触摸库维护，在TKDriver.h中extern声明 */
/* Bit_SYS_Read_Key 在SC_TK_Scan.h中extern声明 */

void HAL_Key_Init(void)
{
    TK_Init();
}

uint32_t HAL_Key_Scan(void)
{
    return (uint32_t)Sys_Scan();
}
