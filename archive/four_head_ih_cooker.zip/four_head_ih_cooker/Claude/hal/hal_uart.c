/**
 * hal_uart.c —— UART1调试打印实现
 *
 * 依赖: hal_uart.h + sc32f1xxx_uart.h
 *
 * UART1: APB0时钟48MHz, Prescaler=/4→12MHz, Baud=115200
 * 阻塞式TX —— 仅调试用，不影响实时消息调度
 */
#include "hal_uart.h"
#include "sc32f1xxx_uart.h"
#include "sc32f1xxx_rcc.h"
#include "sc32f1xxx_gpio.h"
#include "sc32L14xx.h"

/* 调试串口: UART1, 115200-8-N-1
 * TX: PB7 (UART1_TX default mapping)
 * RX: PB6 (UART1_RX default mapping, unused for debug output)
 */
#define DEBUG_UART        UART1
#define DEBUG_UART_TX_PIN GPIO_Pin_7
#define DEBUG_UART_RX_PIN GPIO_Pin_6
#define DEBUG_UART_PORT    GPIOB
#define DEBUG_BAUDRATE     115200u

void HAL_UART_Debug_Init(void)
{
    UART_InitTypeDef uart_init;
    GPIO_InitTypeDef gpio_init;

    /* 使能UART1时钟 */
    RCC_APB0PeriphClockCmd(RCC_APB0Periph_UART1, ENABLE);

    /* TX pin: PB7 推挽输出 */
    gpio_init.GPIO_Pin        = DEBUG_UART_TX_PIN;
    gpio_init.GPIO_Mode       = GPIO_Mode_OUT_PP;
    gpio_init.GPIO_DriveLevel = GPIO_DriveLevel_0;
    GPIO_Init(DEBUG_UART_PORT, &gpio_init);

    /* RX pin: PB6 高阻输入（调试不接收但配置以防浮空） */
    gpio_init.GPIO_Pin        = DEBUG_UART_RX_PIN;
    gpio_init.GPIO_Mode       = GPIO_Mode_IN_HI;
    gpio_init.GPIO_DriveLevel = GPIO_DriveLevel_0;
    GPIO_Init(DEBUG_UART_PORT, &gpio_init);

    /* UART1: 10bit模式(8N1), APB/4=12MHz → 115200 */
    uart_init.UART_ClockFrequency = 12000000u;
    uart_init.UART_BaudRate       = DEBUG_BAUDRATE;
    uart_init.UART_Mode           = UART_Mode_10B;
    UART_Init(DEBUG_UART, &uart_init);

    /* 使能TX */
    UART_TXCmd(DEBUG_UART, ENABLE);
}

void HAL_UART_Debug_PutChar(uint8_t ch)
{
    /* 等待TX完成标志 */
    while (UART_GetFlagStatus(DEBUG_UART, UART_Flag_TX) == RESET) {}
    UART_SendData(DEBUG_UART, ch);
}

void HAL_UART_Debug_Print(const char *str)
{
    while (*str != '\0') {
        if (*str == '\n') {
            HAL_UART_Debug_PutChar('\r');
        }
        HAL_UART_Debug_PutChar((uint8_t)*str);
        str++;
    }
}

void HAL_UART_Debug_HexDump(const uint8_t *data, uint16_t len)
{
    static const char hex[] = "0123456789ABCDEF";
    uint16_t i;
    for (i = 0u; i < len; i++) {
        HAL_UART_Debug_PutChar((uint8_t)hex[data[i] >> 4u]);
        HAL_UART_Debug_PutChar((uint8_t)hex[data[i] & 0x0Fu]);
        HAL_UART_Debug_PutChar(' ');
    }
    HAL_UART_Debug_PutChar('\n');
}
