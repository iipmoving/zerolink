..\output\disp_dispose_ai.o: ..\User_Main\APP\Disp_Dispose_AI.c
..\output\disp_dispose_ai.o: ..\User_Main\APP\Disp_Dispose_AI.h
..\output\disp_dispose_ai.o: ..\User_Main\APP_Driver\LED_Drive.h
