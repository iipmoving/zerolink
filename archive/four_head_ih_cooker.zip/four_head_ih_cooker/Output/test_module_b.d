..\output\test_module_b.o: ..\Claude\test\test_module_b.c
..\output\test_module_b.o: ..\Claude\core/msg_scheduler.h
..\output\test_module_b.o: ..\Claude\core/msg_def.h
..\output\test_module_b.o: C:\Keil_v5\ARM\ARMCC\Bin\..\include\stdint.h
..\output\test_module_b.o: C:\Keil_v5\ARM\ARMCC\Bin\..\include\stddef.h
..\output\test_module_b.o: ..\Claude\hal/hal_uart.h
