..\output\hal_key.o: ..\Claude\hal\hal_key.c
..\output\hal_key.o: ..\Claude\hal\hal_key.h
..\output\hal_key.o: C:\Keil_v5\ARM\ARMCC\Bin\..\include\stdint.h
..\output\hal_key.o: ..\Claude\hal\../lib/SC_TK_Scan.h
..\output\hal_key.o: ..\Claude\hal\../lib/MCU_Drivers/TKDriverNew/TKDriver.h
