..\output\sys_mem.o: ..\User_Main\US_Main\sys_mem.c
..\output\sys_mem.o: ..\User_Main\US_Main\func_def.h
..\output\sys_mem.o: ..\User_Main\US_Main\sys_mem.h
