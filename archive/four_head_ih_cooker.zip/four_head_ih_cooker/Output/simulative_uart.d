..\output\simulative_uart.o: ..\User_Main\Function_Application\Simulative_Uart.c
..\output\simulative_uart.o: ..\User_Main\US_Main\func_def.h
..\output\simulative_uart.o: ..\User_Main\Function_Application\Simulative_Uart.h
..\output\simulative_uart.o: ..\User_Main\US_Main\Dbug_DATA_OUT.h
