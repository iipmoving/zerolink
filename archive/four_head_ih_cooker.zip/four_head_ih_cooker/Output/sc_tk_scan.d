..\output\sc_tk_scan.o: ..\Claude\lib\SC_TK_Scan.c
..\output\sc_tk_scan.o: ..\Claude\lib\SC_TK_Scan.h
..\output\sc_tk_scan.o: ..\MCU_Drivers\.\TKDriverNew\TKDriver.h
