..\output\test_module_a.o: ..\Claude\test\test_module_a.c
..\output\test_module_a.o: ..\Claude\core/msg_scheduler.h
..\output\test_module_a.o: ..\Claude\core/msg_def.h
..\output\test_module_a.o: C:\Keil_v5\ARM\ARMCC\Bin\..\include\stdint.h
..\output\test_module_a.o: C:\Keil_v5\ARM\ARMCC\Bin\..\include\stddef.h
..\output\test_module_a.o: ..\Claude\hal/hal_uart.h
