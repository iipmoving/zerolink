..\output\drv_key.o: ..\Claude\drv\drv_key.c
..\output\drv_key.o: ..\Claude\drv\drv_key.h
..\output\drv_key.o: C:\Keil_v5\ARM\ARMCC\Bin\..\include\stdint.h
..\output\drv_key.o: ..\Claude\drv\../core/msg_scheduler.h
..\output\drv_key.o: ..\Claude\drv\../core/msg_def.h
..\output\drv_key.o: C:\Keil_v5\ARM\ARMCC\Bin\..\include\stddef.h
..\output\drv_key.o: ..\Claude\drv\../hal/hal_key.h
..\output\drv_key.o: ..\Claude\drv\../lib/SC_TK_Scan.h
