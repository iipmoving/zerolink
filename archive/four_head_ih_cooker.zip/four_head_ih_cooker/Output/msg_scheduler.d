..\output\msg_scheduler.o: ..\Claude\core\msg_scheduler.c
..\output\msg_scheduler.o: ..\Claude\core\msg_scheduler.h
..\output\msg_scheduler.o: ..\Claude\core\msg_def.h
..\output\msg_scheduler.o: C:\Keil_v5\ARM\ARMCC\Bin\..\include\stdint.h
..\output\msg_scheduler.o: C:\Keil_v5\ARM\ARMCC\Bin\..\include\stddef.h
