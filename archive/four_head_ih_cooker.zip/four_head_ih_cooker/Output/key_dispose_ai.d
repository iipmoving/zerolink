..\output\key_dispose_ai.o: ..\User_Main\APP\Key_dispose_AI.c
..\output\key_dispose_ai.o: ..\User_Main\APP_Driver\Key_Driver.h
..\output\key_dispose_ai.o: ..\User_Main\Function_Application\Key_Driver_Lib.h
..\output\key_dispose_ai.o: ..\User_Main\APP\Key_dispose_AI.h
