..\output\adc_dispose.o: ..\User_Main\APP_Driver\ADC_Dispose.c
..\output\adc_dispose.o: ..\User_Main\US_Main\func_def.h
..\output\adc_dispose.o: ..\User_Main\Function_Application\Simulative_Uart.h
..\output\adc_dispose.o: ..\User_Main\US_Main\Dbug_DATA_OUT.h
..\output\adc_dispose.o: ..\MCU_Apps\ADC_SequenceConversion.h
..\output\adc_dispose.o: ..\User_Main\APP_Driver\ADC_Dispose.h
