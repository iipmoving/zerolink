..\output\key_driver.o: ..\User_Main\APP_Driver\Key_Driver.c
..\output\key_driver.o: ..\User_Main\US_Main\func_def.h
..\output\key_driver.o: ..\User_Main\APP_Driver\Key_Driver.h
..\output\key_driver.o: ..\User_Main\Function_Application\Key_Driver_Lib.h
..\output\key_driver.o: ..\MCU_Apps\SC_TK_Scan.h
